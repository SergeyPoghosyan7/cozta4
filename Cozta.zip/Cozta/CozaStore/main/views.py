from typing import Any
from django.shortcuts import render , redirect
from django.views import generic
from django.template.defaultfilters import date
from django.core.mail import send_mail
from CozaStore.settings import EMAIL_HOST_USER
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .forms import (
    ContactUsForm , CommentForm
)
from .models import *
from django.db.models import Q
class BlogSearchView(generic.ListView):

    model = Product
    template_name = 'index.html'
    context_object_name = "posts"


    def  get_queryset(self):
        query = self.request.GET.get("q", "")
        if query:
            post  = Product.objects.filter(Q(name__icontains=query) | Q(category__icontains=query))
        else:
            post =  Product.objects.all()

        # products = Product.objects.all()
        return  post
    



class HomeListView(generic.ListView):
    template_name = 'index.html'
   

    @staticmethod
    def __extract_all_data():
        
        sliders = Slider.objects.all()
        products = Product.objects.all()
        categories = Category.objects.all()
        
        context = {
            'nav':'home',
            'sliders':sliders,
            'products' : products,
            'categories':categories,
        }   

        return context

    def get(self, request):
        

        return render(request, self.template_name , context = self.__extract_all_data())
    

class AboutListView(generic.ListView):
    template_name = 'about.html'

    def get(self, request):
        abouts = About.objects.all()


        context = {
            'nav':'about',
            'abouts':abouts,

        }    
        
        return render(request, self.template_name , context = context)
    


class BlogListView(generic.ListView):
    template_name = 'blog.html'
    paginate_by = 3 

    @staticmethod
    def __extract_blog_data(request, items_per_page):
        blogs = Blog.objects.all()
        paginator = Paginator(blogs, items_per_page)  
        page = request.GET.get('page')

        try:
            blogs = paginator.page(page)
        except PageNotAnInteger:
            blogs = paginator.page(1)
        except EmptyPage:
            blogs = paginator.page(paginator.num_pages)

        context = {
            'nav': 'blog',
            'blogs': blogs,
        }
        return context

    def get(self, request):
        context = self.__extract_blog_data(request, self.paginate_by) 
        return render(request, self.template_name , context = context)
    

class BlogDetailView(generic.DetailView):
    template_name = 'blog-detail.html'


    @staticmethod
    def __extract_blog_data(blog_id):
        blog = Blog.objects.get(pk=blog_id)
        comments = Comment.objects.all()


        context = {
            'nav': 'blog',
            'blog' : blog,
            'comments':comments,
        } 

        return context

    def get(self, request, blog_id): 
        
        return render(request, self.template_name , context = self.__extract_blog_data(blog_id))
    
    def post(self, request, blog_id):
        blog = Blog.objects.get(pk=blog_id)
        data = request.POST.copy()
        data['blog'] = blog

        form = CommentForm(data)
        print(form.data)
        if form.is_valid():
            form.save()
        else:
            form = CommentForm()

        context = self.__extract_blog_data(blog_id)
        context.update({'form':form})
        return render(request, self.template_name, context = context)


class ContactListView(generic.ListView):
    template_name = 'contact.html'

    def get(self, request):

        info = ContactInformation.objects.get()

        context = {
            'nav':'contact',
            'info':info,

        }    
        
        return render(request, self.template_name , context = context)
    
    def post(self, request):
        form = ContactUsForm(request.POST)

        if form.is_valid():
            email = form.cleaned_data.get('email')
            send_mail(
                from_email=EMAIL_HOST_USER,
                recipient_list=[email],
                subject='CozaStore Support',
                message='We get your request',
                fail_silently=False
            )

            form.save()
        else:
            form = ContactUsForm()
        
        return render(request, self.template_name , context = {'form' : form})


class ProductListView(generic.ListView):
    template_name = 'product.html'

    def get(self, request):

        products = Product.objects.all()
        categories = Category.objects.all()

        context = {
            'nav':'shop',
            'products':products,
            'categories':categories,
        }    
        
        return render(request, self.template_name , context = context)
    

class ProductDetailView(generic.DetailView):
    template_name = 'product-detail.html'

    def get(self, request, slug):
        context = {

        }    
        
        return render(request, self.template_name , context = context)
    

class ShoppingCartListView(generic.ListView):
    template_name = 'shoping-cart.html'

    def get(self, request):
        context = {
            'nav':'features',

        }    
        
        return render(request, self.template_name , context = context)
    


class SearchForm(generic.ListView):
    template_name = 'index.html'
    def get_queryset(self):
        return Serach.objects.filter(title__icontains = self.request.GET.get("q"))
    
    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        context = super().get_context_data(**kwargs)
        context["q"] = self.request.GET.get("q")
        return context
    

