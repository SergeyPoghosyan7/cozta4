from django.contrib import admin
from django.apps import apps
from .models import *

models = apps.get_models()

@admin.register(Blog)
class BlogModelAdmin(admin.ModelAdmin):
    list_display = ['title', 'assortment', 'user' , 'date' , 'img_preview']
    list_display_links = ['title', 'user' , 'date', 'img_preview']
    list_editable = ['assortment']
    date_hierarchy = 'date'
    list_per_page = 10
    search_fields = ['title', 'assortment', 'user' , 'date']


#----------------------------------------------Auto-Register----------------------------------------------
for model in models:
    try:
        admin.site.register(model)
    except admin.sites.AlreadyRegistered:
        pass
#---------------------------------------------------------------------------------------------------------
