search = document.querySelector(".input-search")
btn = document.querySelector(".change-btn")


// search.addEventListener("keypress" , (e)=>{
// // console.log(e.target.value);
// // alert(e.target.value)
// btn.click();
// })