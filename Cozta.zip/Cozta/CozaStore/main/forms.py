from django.forms import ModelForm
from .models import ContactUs, Comment ,Serach
from django import forms

class ContactUsForm(ModelForm):
    class Meta:
        model = ContactUs
        fields = '__all__'



class CommentForm(ModelForm):
    class Meta:
        model = Comment
        fields = '__all__'


class SearchForm(ModelForm):
    

    class Meta:
        model = Serach
        fields = "__all__"
        